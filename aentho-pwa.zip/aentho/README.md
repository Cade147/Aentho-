# Aentho — Offline-First Business Dashboard PWA

A production-ready Progressive Web App for small businesses in low-connectivity environments.
Track sales, manage inventory, record expenses, and generate reports — online or offline.

---

## File Structure

```
aentho/
├── index.html              ← Login page (entry point)
├── signup.html             ← Registration page
├── dashboard.html          ← Main app shell + all sections
├── manifest.json           ← PWA manifest (installable on Android)
├── service-worker.js       ← Offline caching + background sync
├── README.md
├── assets/
│   └── icons/              ← PWA icons (72, 96, 128, 144, 192, 512px)
├── styles/
│   ├── main.css            ← Design tokens, base styles, components
│   ├── auth.css            ← Login/signup page styles
│   └── dashboard.css       ← Dashboard layout, sidebar, cards
└── scripts/
    ├── ui.js               ← Toast, modals, formatters, icons, helpers
    ├── db.js               ← IndexedDB layer (all CRUD for all stores)
    ├── auth.js             ← Firebase Auth (email, Google, session)
    ├── sync.js             ← Offline→Firestore sync when online
    ├── app.js              ← Main controller: routing, nav, settings boot
    ├── dashboard.js        ← Overview KPIs, charts, alerts
    ├── sales.js            ← Sales tracking module
    ├── inventory.js        ← Inventory / product management
    ├── expenses.js         ← Expense tracking module
    ├── analytics.js        ← Chart.js analytics charts
    ├── reports.js          ← Reports + CSV/print export
    └── notifications.js    ← Notification centre
```

---

## Firebase Configuration

The config is in `scripts/auth.js` (lines 10–17):

| Key | Used for |
|-----|----------|
| `apiKey` | Authenticating Firebase SDK requests |
| `authDomain` | Google Sign-In popup + email auth |
| `projectId` | Firestore database ID |
| `storageBucket` | (Future: file/image uploads) |
| `messagingSenderId` | (Future: push notifications) |
| `appId` | Identifies your Firebase app |
| `measurementId` | Google Analytics (optional) |

**Firestore data structure:**
```
users/{uid}/sales/{saleId}
users/{uid}/products/{productId}
users/{uid}/expenses/{expenseId}
```

---

## Deployment

### GitHub Pages
```bash
git init
git add .
git commit -m "Initial Aentho deployment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/aentho.git
git push -u origin main
# Enable GitHub Pages → Settings → Pages → Branch: main / root
```

### Firebase Hosting
```bash
npm install -g firebase-tools
firebase login
firebase init hosting   # public dir: .  (dot)  |  SPA: No
firebase deploy
```

### Vercel
```bash
npm install -g vercel
vercel --prod
# Set output directory to: . (root)
```

---

## Android APK (Capacitor)
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init Aentho com.aentho.app --web-dir .
npx cap add android
npx cap sync
npx cap open android
# Build APK in Android Studio: Build → Generate Signed APK
```

---

## Firebase Security Rules (Firestore)
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

---

## Offline Behaviour
- All data is written to **IndexedDB** first (always works, no internet needed)
- Every write is added to a **sync queue**
- When internet returns, the queue syncs to **Firestore** automatically
- Service Worker caches all app assets on first load for full offline use

